import csv

"""
Programm welches zwei csv dateien mit unterschiedlichen dialekt einliesst und
als csv mit einem ; dilekt speichert.
"""
__author__ = "Schwarz Stephan"
__version__ = "1.0"

out = []

# read file 1
ifile = open('input1.csv', "rt")
dialect1 = csv.Sniffer().sniff(ifile.read(1024))
ifile.seek(0)
reader = csv.reader(ifile, dialect1)

# read file 2
ifile2 = open('input2.csv', "rt")
dialect2 = csv.Sniffer().sniff(ifile2.read(1024))
ifile2.seek(0)
reader2 = csv.reader(ifile2, dialect2)

# write file 3
ofile = open('output.csv', "wt")
# dialect with ;
csv.register_dialect('semicolon', delimiter=';')
writer = csv.writer(ofile, dialect='semicolon')


for row in reader:
    out.append(row)

for row in reader2:
    out.append(row)

for i in out:
    writer.writerow(i)

# close files
ifile.close()
ifile2.close()
ofile.close()
